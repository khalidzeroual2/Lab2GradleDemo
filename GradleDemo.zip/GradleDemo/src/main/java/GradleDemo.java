public class GradleDemo {

    public static  void main(String [] args){
        System.out.println("My Gradle Demo");
    }
}
