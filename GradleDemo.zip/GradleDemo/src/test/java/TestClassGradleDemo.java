import org.testng.annotations.Test;

public class TestClassGradleDemo {
    @Test
    public void testGradleDemo(){
 System.out.println("test my Gradle Demo");
}
}